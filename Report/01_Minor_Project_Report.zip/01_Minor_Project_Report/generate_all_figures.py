import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np
import os

# Create images dir if not exists
os.makedirs('images', exist_ok=True)

# Set high-DPI publication styling with much larger, readable fonts
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['font.size'] = 14.0
plt.rcParams['axes.titlesize'] = 16.0
plt.rcParams['axes.labelsize'] = 14.0
plt.rcParams['figure.titlesize'] = 18.0
plt.rcParams['figure.dpi'] = 300

# Professional academic palette
C_PRIMARY = '#1f497d'
C_SECONDARY = '#2e75b6'
C_ACCENT = '#008080'
C_ALERT = '#c00000'
C_SUCCESS = '#2e7d32'

# =============================================================================
# FIGURE 1: Overall System Architecture (Fixed Arrows & Visibility)
# =============================================================================
fig, ax = plt.subplots(figsize=(16, 5), dpi=300)
ax.axis('off')

stages = [
    ("Input PDF", "Multi-column\ndigital doc"),
    ("Layout Ingestion", "PyMuPDF\nbounding boxes"),
    ("Reading Order", "2D Column-Aware\nGeometric Sorting"),
    ("Concept Extraction", "Heading Landmarks\n& Evidence Anchors"),
    ("Hierarchy Induction", "CPG++ Candidates\n& PRE Ranking"),
    ("Knowledge Forest", "Rooted Tree Forest\n& Validation")
]

box_w = 1.8
box_h = 1.0
spacing = 2.4

for i, (title, desc) in enumerate(stages):
    x = i * spacing + 0.2
    y = 0.5
    bg = '#dbe9f4' if i in [0, 5] else '#f0f4f8'
    edge = C_PRIMARY if i in [0, 5] else '#4a6572'
    lw = 3.0 if i in [0, 5] else 2.0
    
    rect = patches.FancyBboxPatch((x, y), box_w, box_h, boxstyle="round,pad=0.1,rounding_size=0.1",
                                  facecolor=bg, edgecolor=edge, linewidth=lw)
    ax.add_patch(rect)
    
    ax.text(x + box_w/2, y + box_h*0.7, title, ha='center', va='center',
            fontsize=14.0, fontweight='bold', color='#102a43')
    ax.text(x + box_w/2, y + box_h*0.3, desc, ha='center', va='center',
            fontsize=12.0, color='#334e68')
    
    # Draw clear arrows pointing from left box to right box
    if i < len(stages) - 1:
        start_x = x + box_w
        end_x = x + box_w + (spacing - box_w)
        ax.annotate('', xy=(end_x - 0.1, y + box_h/2), xytext=(start_x + 0.1, y + box_h/2),
                    arrowprops=dict(arrowstyle="-|>", color=C_PRIMARY, lw=3.0, mutation_scale=20))

ax.set_xlim(-0.2, len(stages) * spacing)
ax.set_ylim(0.0, 2.0)
plt.title("End-to-End Functional Pipeline of SHIA-RAG Architecture", fontsize=18, fontweight='bold', pad=20)
plt.tight_layout()
plt.savefig('images/fig1_overall_architecture.png', bbox_inches='tight')
plt.close()

# =============================================================================
# FIGURE 2: 2D Geometric Reading Order (Fixed zigzag and downwards arrows)
# =============================================================================
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6), dpi=300)

for ax in (ax1, ax2):
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 10)
    ax.axis('off')

# Left panel: Naive text extraction (Bad)
ax1.set_title("Naive PDF Text Stream\n(Cross-Column Zigzag Error)", fontsize=14, fontweight='bold', color=C_ALERT)
col1_y = [7.5, 5.0, 2.5]
col2_y = [7.5, 5.0, 2.5]

for idx, y in enumerate(col1_y):
    ax1.add_patch(patches.Rectangle((0.5, y), 4.0, 1.5, facecolor='#fdedec', edgecolor='#c0392b', lw=2.0))
    ax1.text(2.5, y + 0.75, f"Left Block {idx+1}", ha='center', va='center', fontsize=12, fontweight='bold', color='#900c3f')

for idx, y in enumerate(col2_y):
    ax1.add_patch(patches.Rectangle((5.5, y), 4.0, 1.5, facecolor='#fdedec', edgecolor='#c0392b', lw=2.0))
    ax1.text(7.5, y + 0.75, f"Right Block {idx+1}", ha='center', va='center', fontsize=12, fontweight='bold', color='#900c3f')

# Correct the bad arrows: The PDF reader reads straight across horizontally instead of downwards!
# Start at Left Block 1, go to Right Block 1, then Left Block 2, etc.
bad_flow = [(2.5, 8.25), (7.5, 8.25), (2.5, 5.75), (7.5, 5.75), (2.5, 3.25), (7.5, 3.25)]
for i in range(len(bad_flow)-1):
    start = bad_flow[i]
    end = bad_flow[i+1]
    # For cross-column, curve the arrow so it doesn't overlap text
    rad = 0.2 if i % 2 != 0 else 0.0
    ax1.annotate('', xy=end, xytext=start,
                 arrowprops=dict(arrowstyle="->", color=C_ALERT, lw=3.0, linestyle='--', connectionstyle=f"arc3,rad={rad}", mutation_scale=20))

# Right panel: Proposed 2D Geometric Sorting (Good)
ax2.set_title("SHIA-RAG 2D Geometric Sorting\n(Correct Logical Flow)", fontsize=14, fontweight='bold', color=C_SUCCESS)
for idx, y in enumerate(col1_y):
    ax2.add_patch(patches.Rectangle((0.5, y), 4.0, 1.5, facecolor='#e8f5e9', edgecolor='#27ae60', lw=2.0))
    ax2.text(2.5, y + 0.75, f"Block {idx+1}", ha='center', va='center', fontsize=12, fontweight='bold', color='#1e824c')

for idx, y in enumerate(col2_y):
    ax2.add_patch(patches.Rectangle((5.5, y), 4.0, 1.5, facecolor='#e8f5e9', edgecolor='#27ae60', lw=2.0))
    ax2.text(7.5, y + 0.75, f"Block {idx+4}", ha='center', va='center', fontsize=12, fontweight='bold', color='#1e824c')

# Good arrows: Read down the left column, then down the right column
good_flow = [(2.5, 7.5), (2.5, 6.5)] # Between Left 1 and Left 2
ax2.annotate('', xy=(2.5, 6.5), xytext=(2.5, 7.5), arrowprops=dict(arrowstyle="-|>", color=C_SUCCESS, lw=3.0, mutation_scale=20))
ax2.annotate('', xy=(2.5, 4.0), xytext=(2.5, 5.0), arrowprops=dict(arrowstyle="-|>", color=C_SUCCESS, lw=3.0, mutation_scale=20))

# Big arrow bridging columns
ax2.annotate('', xy=(7.5, 9.0), xytext=(2.5, 2.5),
             arrowprops=dict(arrowstyle="-|>", color='#2980b9', lw=3.0, linestyle='-', connectionstyle="arc3,rad=-0.3", mutation_scale=20))

ax2.annotate('', xy=(7.5, 6.5), xytext=(7.5, 7.5), arrowprops=dict(arrowstyle="-|>", color=C_SUCCESS, lw=3.0, mutation_scale=20))
ax2.annotate('', xy=(7.5, 4.0), xytext=(7.5, 5.0), arrowprops=dict(arrowstyle="-|>", color=C_SUCCESS, lw=3.0, mutation_scale=20))

plt.suptitle("Reading-Order Recovery: Naive Stream vs. SHIA-RAG Column-Aware Sorting", fontsize=16, fontweight='bold')
plt.tight_layout()
plt.savefig('images/fig2_layout_reading_order.png', bbox_inches='tight')
plt.close()

# =============================================================================
# FIGURE 3: Dual-Tier Data Representation Schema
# =============================================================================
fig, ax = plt.subplots(figsize=(12, 6), dpi=300)
ax.axis('off')
ax.set_xlim(0, 12)
ax.set_ylim(0, 7)

# Tier 1 Container
rect1 = patches.FancyBboxPatch((0.5, 0.5), 5.0, 6.0, boxstyle="round,pad=0.2",
                               facecolor='#f4f8fb', edgecolor=C_PRIMARY, lw=3.0)
ax.add_patch(rect1)
ax.text(3.0, 6.1, "Tier 1: Syntactic Model", ha='center', va='center',
        fontsize=14, fontweight='bold', color=C_PRIMARY)

tier1_boxes = [
    ("Document", "pages, block_sequence"),
    ("TextBlock", "bbox(x0,y0,x1,y1), text"),
    ("BoundingBox", "Physical page coordinates")
]
for idx, (title, fields) in enumerate(tier1_boxes):
    y = 4.2 - idx * 1.8
    ax.add_patch(patches.Rectangle((0.8, y), 4.4, 1.2, facecolor='white', edgecolor='#7f8c8d', lw=2.0))
    ax.text(3.0, y + 0.8, title, ha='center', va='center', fontsize=12, fontweight='bold', color='#2c3e50')
    ax.text(3.0, y + 0.3, fields, ha='center', va='center', fontsize=11, color='#595959')

# Tier 2 Container
rect2 = patches.FancyBboxPatch((6.5, 0.5), 5.0, 6.0, boxstyle="round,pad=0.2",
                               facecolor='#fbfcf7', edgecolor=C_SUCCESS, lw=3.0)
ax.add_patch(rect2)
ax.text(9.0, 6.1, "Tier 2: Semantic Forest", ha='center', va='center',
        fontsize=14, fontweight='bold', color=C_SUCCESS)

tier2_boxes = [
    ("ConceptNode", "name, definition, level"),
    ("HierarchyEdge", "parent_id -> child_id"),
    ("KnowledgeForest", "DAG Trees + Cross-Links")
]
for idx, (title, fields) in enumerate(tier2_boxes):
    y = 4.2 - idx * 1.8
    ax.add_patch(patches.Rectangle((6.8, y), 4.4, 1.2, facecolor='white', edgecolor='#7f8c8d', lw=2.0))
    ax.text(9.0, y + 0.8, title, ha='center', va='center', fontsize=12, fontweight='bold', color='#2c3e50')
    ax.text(9.0, y + 0.3, fields, ha='center', va='center', fontsize=11, color='#595959')

# Grounding Anchor Arrow
ax.annotate('Grounding Span',
            xy=(6.5, 3.5), xytext=(5.5, 3.5),
            ha='center', va='center', fontsize=12, fontweight='bold', color=C_ACCENT,
            arrowprops=dict(arrowstyle="<|-|>", color=C_ACCENT, lw=4.0, linestyle='--'))

plt.title("Two-Tier Knowledge Architecture: From Physical Layout to Semantic Graph", fontsize=16, fontweight='bold', pad=20)
plt.tight_layout()
plt.savefig('images/fig3_dual_tier_forest.png', bbox_inches='tight')
plt.close()

# =============================================================================
# FIGURE 4: Hierarchy Induction Decision Pipeline
# =============================================================================
fig, ax = plt.subplots(figsize=(14, 4), dpi=300)
ax.axis('off')
ax.set_xlim(0, 14)
ax.set_ylim(0, 4)

steps = [
    ("Child Node", "Extracted definition"),
    ("CPG++ Filter", "Order precedence"),
    ("PRE Scoring", "w_struct*S_struct\nw_sem*S_sem"),
    ("Upward DFS", "Prevents Cycles"),
    ("Tree Insert", "Assign (u*, c_i)")
]

for i, (title, desc) in enumerate(steps):
    x = i * 2.8 + 0.2
    rect = patches.FancyBboxPatch((x, 1.0), 2.2, 2.0, boxstyle="round,pad=0.1",
                                  facecolor='#edf2f7', edgecolor='#4a6572', lw=2.0)
    ax.add_patch(rect)
    ax.text(x + 1.1, 2.3, title, ha='center', va='center', fontsize=14, fontweight='bold', color='#1a202c')
    ax.text(x + 1.1, 1.5, desc, ha='center', va='center', fontsize=12, color='#4a5568')
    if i < len(steps) - 1:
        ax.annotate('', xy=(x + 2.8, 2.0), xytext=(x + 2.2, 2.0),
                    arrowprops=dict(arrowstyle="-|>", color=C_PRIMARY, lw=3.0, mutation_scale=20))

plt.title("Hierarchical Parent Assignment Workflow (CPG++ & PRE)", fontsize=16, fontweight='bold', pad=15)
plt.tight_layout()
plt.savefig('images/fig4_hierarchy_induction.png', bbox_inches='tight')
plt.close()

# =============================================================================
# FIGURE 6: Reading-Order Recovery & Inversion Rate Comparison (Bar Charts)
# =============================================================================
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5), dpi=300)

strategies = ['Naive Text\nStream', 'Top-Down\n(y0 only)', 'SHIA-RAG\n2D Geometric']
rom_vals = [71.4, 83.2, 100.0]
inv_vals = [28.6, 16.8, 0.0]
strat_colors = ['#e74c3c', '#f39c12', '#27ae60']

bars_rom = ax1.bar(strategies, rom_vals, color=strat_colors, width=0.5, edgecolor='#2c3e50', lw=2.0)
ax1.set_title("Reading-Order Monotonicity (ROM)", fontsize=14, fontweight='bold')
ax1.set_ylabel("Monotonicity Rate (%)", fontsize=14)
ax1.set_ylim(0, 120)
ax1.grid(axis='y', linestyle='--', alpha=0.5)
ax1.tick_params(axis='both', labelsize=12)
for bar in bars_rom:
    yval = bar.get_height()
    ax1.text(bar.get_x() + bar.get_width()/2, yval + 2, f"{yval:.1f}%", ha='center', va='bottom', fontsize=12, fontweight='bold')

bars_inv = ax2.bar(strategies, inv_vals, color=strat_colors, width=0.5, edgecolor='#2c3e50', lw=2.0)
ax2.set_title("Inversion Error Rate", fontsize=14, fontweight='bold')
ax2.set_ylabel("Inversion Rate (%)", fontsize=14)
ax2.set_ylim(0, 35)
ax2.grid(axis='y', linestyle='--', alpha=0.5)
ax2.tick_params(axis='both', labelsize=12)
for bar in bars_inv:
    yval = bar.get_height()
    ax2.text(bar.get_x() + bar.get_width()/2, yval + 1, f"{yval:.1f}%", ha='center', va='bottom', fontsize=12, fontweight='bold')

plt.suptitle("Reading-Order Recovery Comparison Across Ingestion Strategies", fontsize=16, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig('images/fig6_treerag_case_study.png', bbox_inches='tight')
plt.close()

# =============================================================================
# FIGURE 7: Empirical Baseline Comparisons (PAA & NTED)
# =============================================================================
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5), dpi=300)

methods = ['Sequential\nNesting', 'Lexical\nPrefix', 'Syntactic\nHeading', 'SHIA-RAG\n(PRE)']
paa_scores = [44.2, 68.5, 77.4, 89.6]
nted_scores = [0.481, 0.672, 0.783, 0.884]
colors = ['#95a5a6', '#7f8c8d', '#2980b9', '#27ae60']

bars1 = ax1.bar(methods, paa_scores, color=colors, width=0.5, edgecolor='#2c3e50', lw=2.0)
ax1.set_title("Parent Assignment Accuracy (PAA)", fontsize=14, fontweight='bold', color=C_PRIMARY)
ax1.set_ylabel("Accuracy (%)", fontsize=14)
ax1.set_ylim(0, 110)
ax1.grid(axis='y', linestyle='--', alpha=0.5)
ax1.tick_params(axis='both', labelsize=12)
for bar in bars1:
    yval = bar.get_height()
    ax1.text(bar.get_x() + bar.get_width()/2, yval + 2, f"{yval:.1f}%", ha='center', va='bottom', fontsize=12, fontweight='bold')

bars2 = ax2.bar(methods, nted_scores, color=colors, width=0.5, edgecolor='#2c3e50', lw=2.0)
ax2.set_title("Normalized Tree Edit Distance (NTED)", fontsize=14, fontweight='bold', color=C_PRIMARY)
ax2.set_ylabel("NTED Score", fontsize=14)
ax2.set_ylim(0, 1.1)
ax2.grid(axis='y', linestyle='--', alpha=0.5)
ax2.tick_params(axis='both', labelsize=12)
for bar in bars2:
    yval = bar.get_height()
    ax2.text(bar.get_x() + bar.get_width()/2, yval + 0.02, f"{yval:.3f}", ha='center', va='bottom', fontsize=12, fontweight='bold')

plt.suptitle("Hierarchy Induction Performance Across Baselines on CS-Textbook Benchmark", fontsize=16, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig('images/fig7_evaluation_metrics.png', bbox_inches='tight')
plt.close()

print("Massively improved figures generated successfully!")
