# Minor Project — Presentation Content
## Hierarchical Document-Tree Construction for Structure-Aware RAG

Use your NITK template. ~11 slides. Put `tree_vs_chunks_figure.png` on the Results slide.

---

**Slide 1 — Title**
Hierarchical Document-Tree Construction for Structure-Aware RAG · Minor Project (IT897) · Kshitij
Khede (252IT010) · Guide: Prof. Ananthanarayana V. S. · NITK Surathkal.

**Slide 2 — Table of Contents**
Introduction · Literature Survey · Problem & Objectives · System Design · Results & Comparison ·
Demo · Conclusion & Future Work · References.

**Slide 3 — Introduction**
- RAG answers from retrieved document text — how the document is represented decides what's retrieved.
- Standard RAG uses **flat, fixed-size chunks**.
- A fixed-size window is cut arbitrarily: it spans two sections and loses the section→subsection link.
- Documents are really **hierarchies** (title → sections → subsections).
- *Say:* "My project turns a PDF into that hierarchy — a tree, not flat chunks."

**Slide 4 — Literature Survey**
- Flat RAG (RAG, REALM, RETRO, Atlas) — flat chunks, no structure.
- Tree/structure-aware RAG (RAPTOR, TreeRAG, HiChunk) — retrieve along a document tree, but **assume
  the tree exists**; HiChunk even needs a fine-tuned LLM to get it.
- **Gap:** constructing the tree from a raw PDF, cheaply and training-free, is the under-served step.

**Slide 5 — Problem & Objectives**
- **Problem:** flat chunking discards document structure; build a system that converts a PDF into a
  hierarchical section tree and quantify the structure it preserves vs flat chunks.
- **Objectives:** PDF→tree pipeline · reading-order recovery · heading detection · validated hierarchy
  + confidence · accuracy evaluation · tree-vs-chunk comparison · web demo.

**Slide 6 — System Design (pipeline)**
- Six stages: Ingestion → Reading-order recovery → Heading classification → Hierarchy induction →
  Validation → KCE confidence → **document tree**.
- Only ingestion uses a library; the other five stages are my algorithms.
- *Figure:* the pipeline diagram (from the report).

**Slide 7 — Key Algorithms**
- **Reading-order recovery:** column-gutter rule (split at W/2 → left/right/spanning → order).
- **Hierarchy induction:** numbering-primary ("3.1"→"3"); unnumbered → PRE score
  = 0.40·proximity + 0.40·TF–IDF + 0.20·level.
- **Validation:** acyclic, single-parent, depth ≤ 8. **Confidence:** KCE via Kahn's algorithm.

**Slide 8 — Results: Tree Construction**
- 11 research papers; gold = each document's own section numbering.
- **11/11 valid trees**; mean 22.2 nodes, 21.2 links, depth 2.4.
- **PAA 97.7% · APA 96.8% · ACP 97.3%.**
- Perfect/near-perfect on 10 of 11; Self-RAG (78.9%) has irregular numbering (honest limitation).

**Slide 9 — Results: Tree vs Flat Chunks**  *(put `tree_vs_chunks_figure.png` here)*
- Flat chunking: 68.7 chunks/doc, **18.8% straddle ≥2 sections**, **0** parent–child links.
- Tree: **0%** straddle, **21.2** parent–child links preserved per document.
- *Say:* "This is the core result — the tree keeps structure that flat chunking destroys."

**Slide 10 — Demonstration**
- Flask web app: upload any PDF → see summary, reading order, the tree as a node–link diagram with
  per-node confidence, and validation status.
- Makes the whole construction inspectable, on any document.

**Slide 11 — Conclusion & Future Work + References**
- Delivered a complete PDF→document-tree builder; valid for every document; 97.7% parent accuracy;
  preserves structure flat chunking loses.
- **Future (Major project, kept separate):** retrieval + QA on the tree vs flat-chunk RAG; robustness
  to parser noise; learned structural confidence.
- References: RAPTOR (ICLR 2024), TreeRAG (ACL 2025), HiChunk (2025), RAG (NeurIPS 2020), TF–IDF
  (Salton), Kahn (1962).

---

**Talking-point discipline:** lead with "tree, not chunks"; show the comparison figure; when asked
"where's your work," list the five stages that are your algorithms; keep the major project separate.
