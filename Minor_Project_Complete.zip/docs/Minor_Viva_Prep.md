# Minor Project — Viva Preparation
## Hierarchical Document-Tree Construction for Structure-Aware RAG

**30-second pitch:**
"Standard RAG chops a document into flat, fixed-size chunks, which cut across sections and throw away
the relationship between a subsection and its section. My project builds a system that turns a PDF
into a hierarchical tree — title → sections → subsections — the way TreeRAG and RAPTOR want documents
represented. I built the full pipeline: reading-order recovery, heading detection, hierarchy
induction, validation, and a confidence score per node. On 11 papers it builds a valid tree every
time with 97.7% parent accuracy, and I show directly that flat chunking loses structure the tree keeps."

**One-line contribution:** A complete, working PDF→document-tree builder, evaluated for accuracy and
shown to preserve section structure and parent–child relationships that flat chunking destroys.

---

## A. The guide's key question — "you just used a library, where is YOUR work / result?"
**Answer this head-on and confidently:**
- The **only** library step is ingestion (pdfplumber), which gives raw text boxes with coordinates and
  font sizes — a bag of blocks, **not** a structure. Everything that turns that into a tree is my work:
  1. **Reading-order recovery** — my column-gutter algorithm that un-mixes two-column pages.
  2. **Heading classification** — numbering + relative-font rules with a junk filter.
  3. **Hierarchy induction** — numbering-primary attachment with a semantic (TF–IDF + reading-order +
     level) fallback for unnumbered headings — my scoring function.
  4. **Graph validation** — acyclic, single-parent, depth-bounded, with repair.
  5. **Confidence estimation** — KCE propagated through the tree with Kahn's algorithm.
- **My result** is threefold: (a) a valid tree for **11/11** documents; (b) **97.7% parent accuracy /
  96.8% full-ancestor accuracy** vs each document's own numbering; (c) a **direct comparison** showing
  flat chunking cuts across sections for **18.8%** of chunks and keeps **0** parent–child links, while
  my tree keeps every section intact and preserves **21.2** links per document.
- "pdfplumber gives me the words on the page; deciding that 3.1 belongs under 3, that this line is a
  heading and that one is a caption, and that the tree is valid — that is the project."

---

## B. Basics
**Q. What is RAG?** An LLM answers using text retrieved from an external store at query time, not just
its trained-in memory.
**Q. What is a chunk?** A piece of the document put into the retrieval index. Standard RAG uses flat,
fixed-size chunks (e.g. 1200 characters).
**Q. Why is flat chunking a problem?** A fixed-size window is cut at an arbitrary point, so it often
spans two sections, and a flat list can't represent that a subsection belongs to a section.
**Q. What is a document tree?** A representation where the document is title → sections → subsections
→ paragraphs, with parent–child links — so retrieval can attach a passage's parent section as context.
**Q. How is this related to TreeRAG / RAPTOR?** They retrieve along a document tree but assume the tree
exists. My project builds that tree from a raw PDF, without any training.

## C. Method (know the pipeline)
**Q. Walk me through your pipeline.** Ingestion → reading-order recovery → heading classification →
hierarchy induction → validation → confidence. Output = a validated document tree.
**Q. How do you recover reading order on two-column pages?** Split blocks at the page gutter (W/2) into
left, right and spanning; sort each column top-to-bottom with a 20pt line tolerance; emit spanning,
then left, then right. (Algorithm 1.)
**Q. How do you detect headings?** Two cues: a section number ("3.1") + short title-cased line at
body-or-larger font; or a short title-cased line at ≥1.25× body font. A junk filter drops URLs/DOIs/
references.
**Q. How do you build the hierarchy?** Numbering-primary: "3.1"→"3", single number→root. Unnumbered
headings use PRE: Score = 0.40·(reading-order proximity) + 0.40·(TF–IDF similarity) + 0.20·(level fit).
(Algorithm 2.)
**Q. How do you guarantee it's a valid tree?** Upward DFS checks acyclicity, single parent, depth ≤ 8;
violations are reattached to the nearest valid ancestor.
**Q. What is the confidence score?** KCE: a per-node reliability from the strength of the cues that
placed it, propagated parent→child in topological order (Kahn's algorithm).

## D. Results (know these numbers)
- **11/11 valid trees**; mean 22.2 nodes, 21.2 edges, depth 2.4, branching 4.31.
- **PAA 97.7%, APA 96.8%, ACP 97.3%** against the documents' own section numbering.
- **Flat chunking:** 68.7 chunks/doc, **18.8%** straddle ≥2 sections, **0** parent–child links.
- **Tree:** 22.2 nodes/doc, **0%** straddle, **21.2** parent–child links preserved.
**Q. Why is APA (96.8) a bit below PAA (97.7)?** APA needs the *whole* ancestor chain correct, so a
single wrong link fails the whole path — it is stricter.
**Q. Which document was hardest and why?** Self-RAG (PAA 78.9%): its headings are irregularly numbered,
so more of them fall to the semantic fallback. I report it honestly as a limitation.

## E. Critical questions
**Q. Isn't PAA circular — gold is numbering and you attach by numbering?** For numbered headings the
clean accuracy is partly by construction, which I state; the genuinely non-trivial parts are the
unnumbered-heading placement (semantic fallback) and reading-order recovery. The flat-chunk comparison
is *not* circular — it measures real structure loss.
**Q. Only 11 documents?** Enough to show the tree builds validly and accurately and to make the
flat-chunk comparison; larger and non-academic corpora are in the major project.
**Q. You don't do retrieval or answering?** Correct — the minor is the tree-construction stage; using
the tree for retrieval + QA is Objective 1 of the major project. I kept them separate on purpose.
**Q. What's new vs TreeRAG?** TreeRAG assumes the tree; I construct it from a raw PDF training-free and
measure both its accuracy and what it preserves over flat chunks.

## F. Defense posture
- Lead with **"tree, not chunks"** and the flat-chunk comparison — it's the clearest, most visual result.
- When the "just a library" question comes, calmly list the five stages that are *your* algorithms.
- Own the two honest limits (numbering-derived gold; no retrieval yet) and point each to the major.
- Keep the major project separate — say "that's the major; the minor is the tree builder."
