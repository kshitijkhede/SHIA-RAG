Major-project prototypes (SEPARATE from the minor; build ON TOP OF the minor's tree).

These scripts reuse the minor's tree-construction package (shia_minor), so run them with the
minor's src/ folder on the Python path:

    PYTHONPATH=../src python robustness_eval.py  <folder-of-pdfs> 5
    PYTHONPATH=../src python learned_detector.py <folder-of-pdfs> 10

Files:
  Major_Project_Plan.md        - the major-project plan (objectives O1-O4)
  robustness_eval.py           - O2 prototype: perturbation + PAA/APA/ACP + heuristic repair
  learned_detector.py          - O3 prototype: learned attachment-error detector (LODO CV)
  robustness_results.txt       - raw output of robustness_eval.py
  learned_detector_results.txt - raw output of learned_detector.py
  figures/                     - robustness and learned-detector figures
