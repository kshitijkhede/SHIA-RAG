#!/usr/bin/env python3
"""
LEARNED attachment-error detector for structure-aware RAG (new minor-project component).

Upgrades the hand-crafted KCE-confidence heuristic (which only weakly predicts
attachment errors, point-biserial r ~= 0.16) into a trained classifier that flags
wrong parent-attachments, then gates the repair with the learned signal.

Design (no leakage):
  * For each numbered node under heading-number dropout (delta), after rebuild + KCE,
    we build a feature vector and a label: 1 = predicted parent is WRONG.
  * LEAVE-ONE-DOCUMENT-OUT cross-validation: the model that scores a node was trained
    only on OTHER documents. So every reported number is out-of-fold.
  * Compare error-detection quality: heuristic (1 - KCE conf) vs Logistic Regression
    vs Gradient Boosting  -> ROC-AUC, PR-AUC, point-biserial r.
  * Confidence-gated repair using the LEARNED score vs the heuristic vs no repair
    -> PAA / APA / ACP at delta=0.3.

Usage: python learned_detector.py <folder-of-pdfs> [seeds]
"""
from __future__ import annotations
import sys, random, statistics
from pathlib import Path
import numpy as np

from shia_minor.pdf_ingestion import PDFIngestionService
from shia_minor.structural_parser import StructuralParser
from shia_minor.concept_extractor import ConceptExtractor
from shia_minor.hierarchy_builder import HierarchyBuilder
from shia_minor.kce_scorer import KCEScorer
from shia_minor.pipeline import Pipeline

from robustness_eval import gold_maps, pred_maps, score, perturb

from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score, average_precision_score

FEATURES = [
    "kce_conf", "local_conf", "level", "depth", "font_ratio", "is_bold",
    "has_number", "order_frac", "parent_gap_frac", "parent_level",
    "parent_depth", "to_root", "name_wc", "out_degree", "sibling_ct",
]


def node_features(cs, gp):
    """Return (X rows, y labels, node-keys) for the currently-built concept list."""
    pp, pa = pred_maps(cs)
    nodes = {c.concept_id: c for c in cs}
    n = max(1, len(cs))
    orders = {c.concept_id: c.order for c in cs}
    # predicted-tree degrees
    outdeg, sib = {}, {}
    for c in cs:
        p = pp.get(c.concept_id, "ROOT")
        outdeg[p] = outdeg.get(p, 0) + 1
    for c in cs:
        p = pp.get(c.concept_id, "ROOT")
        sib[c.concept_id] = outdeg.get(p, 1)
    rows, ys, keys = [], [], []
    for k in gp:
        c = nodes[k]
        p = pp.get(k, "ROOT")
        to_root = 1.0 if p == "ROOT" else 0.0
        if p != "ROOT" and p in nodes:
            pgap = abs(orders[k] - orders[p]) / n
            plevel = float(nodes[p].level)
            pdepth = float(nodes[p].depth)
        else:
            pgap, plevel, pdepth = 1.0, 0.0, 0.0
        row = [
            float(c.confidence), float(c.local_confidence), float(c.level),
            float(c.depth), float(c.font_ratio), 1.0 if c.is_bold else 0.0,
            1.0 if c.section_number else 0.0, orders[k] / n, pgap, plevel,
            pdepth, to_root, float(len(c.name.split())),
            float(outdeg.get(k, 0)), float(sib.get(k, 1)),
        ]
        rows.append(row)
        ys.append(0 if pp.get(k, "ROOT") == gp[k] else 1)   # 1 = WRONG (error)
        keys.append(k)
    return rows, ys, keys


def build_dataset(docs, deltas, seeds, builder, kce):
    """Collect (features,label,doc_index) samples over delta grid x seeds."""
    X, y, doc_idx = [], [], []
    for di, (name, concepts, gp, ga) in enumerate(docs):
        for dl in deltas:
            for s in range(seeds):
                rng = random.Random(7000 + s + int(dl * 100))
                cs = perturb(concepts, 0.0, dl, rng)
                builder.build(cs); kce.score(cs)
                rows, ys, _ = node_features(cs, gp)
                X += rows; y += ys; doc_idx += [di] * len(rows)
    return np.array(X, float), np.array(y, int), np.array(doc_idx, int)


def lodo_scores(X, y, doc_idx, model_fn):
    """Leave-one-document-out out-of-fold error probabilities."""
    oof = np.zeros(len(y), float)
    for d in np.unique(doc_idx):
        tr, te = doc_idx != d, doc_idx == d
        if len(np.unique(y[tr])) < 2:
            oof[te] = y[tr].mean(); continue
        sc = StandardScaler().fit(X[tr])
        m = model_fn().fit(sc.transform(X[tr]), y[tr])
        oof[te] = m.predict_proba(sc.transform(X[te]))[:, 1]
    return oof


def pbis(scoresig, y):
    return float(np.corrcoef(scoresig, y)[0, 1]) if len(set(scoresig)) > 1 else 0.0


def run(folder, seeds=10):
    pdfs = sorted(Path(folder).glob("*.pdf"))
    ingest = PDFIngestionService(); pipe = Pipeline()
    extr = ConceptExtractor(); builder = HierarchyBuilder(); kce = KCEScorer()

    docs = []
    for pdf in pdfs:
        blocks = ingest.extract(str(pdf))
        ordered = pipe.sort_blocks(blocks)
        concepts = extr.extract(ordered, pdf.stem[:16])
        gp, ga = gold_maps(concepts)
        if gp:
            docs.append((pdf.stem[:22], concepts, gp, ga))
    print(f"Corpus: {len(docs)} documents with numbered structure\n")

    # ---------- 1) DETECTION: build labeled set over delta in {0.2,0.3,0.4} ----------
    deltas = [0.2, 0.3, 0.4]
    X, y, doc_idx = build_dataset(docs, deltas, seeds, builder, kce)
    print(f"Detection dataset: {len(y)} node-samples "
          f"({deltas} x {seeds} seeds), error rate = {100*y.mean():.1f}%\n")

    heur = 1.0 - X[:, FEATURES.index("kce_conf")]          # heuristic error score
    lr = lodo_scores(X, y, doc_idx, lambda: LogisticRegression(max_iter=2000, class_weight="balanced"))
    gb = lodo_scores(X, y, doc_idx, lambda: GradientBoostingClassifier(random_state=0))

    print("=== Attachment-error DETECTION (leave-one-document-out, out-of-fold) ===")
    print(f"{'detector':32}{'ROC-AUC':>9}{'PR-AUC':>9}{'r':>8}")
    for label, sig in [("heuristic (1 - KCE conf)", heur),
                       ("learned: LogisticRegression", lr),
                       ("learned: GradientBoosting", gb)]:
        print(f"{label:32}{roc_auc_score(y, sig):9.3f}"
              f"{average_precision_score(y, sig):9.3f}{pbis(sig, y):8.3f}")
    print(f"\n(baseline error rate / PR-AUC of a random detector = {y.mean():.3f})\n")

    # feature importance (train GB on all data, for the report/viva only)
    sc = StandardScaler().fit(X)
    gbi = GradientBoostingClassifier(random_state=0).fit(sc.transform(X), y)
    imp = sorted(zip(FEATURES, gbi.feature_importances_), key=lambda t: -t[1])
    print("Top learned-detector features (GB importance):")
    for f, v in imp[:6]:
        print(f"  {f:16}{v:.3f}")
    print()

    # ---------- 2) LEARNED-GATED REPAIR at delta=0.3 (out-of-fold, no leakage) ----------
    # rebuild delta=0.3 samples in a fixed order so we can map oof scores back per (doc,seed)
    print("=== Confidence-gated repair at delta=0.3 (mean over corpus x seeds) ===")
    D3, y3, di3, meta = [], [], [], []
    for dloop_i, (name, concepts, gp, ga) in enumerate(docs):
        for s in range(seeds):
            rng = random.Random(9000 + s)
            cs = perturb(concepts, 0.0, 0.3, rng)
            builder.build(cs); kce.score(cs)
            rows, ys, keys = node_features(cs, gp)
            base = len(D3)
            D3 += rows; y3 += ys; di3 += [dloop_i] * len(rows)
            meta.append((dloop_i, s, gp, ga, keys, base, len(rows)))
    D3 = np.array(D3, float); y3 = np.array(y3, int); di3 = np.array(di3, int)
    lr3 = lodo_scores(D3, y3, di3, lambda: LogisticRegression(max_iter=2000, class_weight="balanced"))
    gb3 = lodo_scores(D3, y3, di3, lambda: GradientBoostingClassifier(random_state=0))

    def repair_with(scoresig, thr):
        """Recompute PAA/APA/ACP applying repair to flagged nodes (score >= thr)."""
        paas, apas, acps = [], [], []
        mi = 0
        for dloop_i, (name, concepts, gp, ga) in enumerate(docs):
            for s in range(seeds):
                _, _, _, _, keys, base, ln = meta[mi]; mi += 1
                rng = random.Random(9000 + s)
                cs = perturb(concepts, 0.0, 0.3, rng)
                builder.build(cs); kce.score(cs)
                flag = {keys[j]: (scoresig[base + j] >= thr) for j in range(ln)} if scoresig is not None else {}
                if scoresig is not None:
                    cs2 = sorted(cs, key=lambda c: c.order)
                    root = next((c for c in cs2 if c.parent_id is None), None)
                    nodes = {c.concept_id: c for c in cs2}
                    for i, c in enumerate(cs2):
                        if c is root:
                            continue
                        if flag.get(c.concept_id, False):
                            newp = root
                            for u in reversed(cs2[:i]):
                                if u.level < c.level:
                                    newp = u; break
                            c.parent_id = newp.concept_id if newp else None
                r = score(cs, gp, ga)
                if r: paas.append(r[0]); apas.append(r[1]); acps.append(r[2])
        return np.mean(paas), np.mean(apas), np.mean(acps)

    # heuristic gate uses confidence < 0.60  ==  (1-conf) > 0.40
    heur3 = 1.0 - D3[:, FEATURES.index("kce_conf")]
    # pick learned thresholds to match the heuristic's repair budget (fair comparison)
    budget = float((heur3 >= 0.40).mean())
    thr_lr = float(np.quantile(lr3, 1 - budget))
    thr_gb = float(np.quantile(gb3, 1 - budget))

    print(f"{'setting':34}{'PAA':>7}{'APA':>7}{'ACP':>7}")
    p = repair_with(None, 0)
    print(f"{'no repair':34}{p[0]:7.1f}{p[1]:7.1f}{p[2]:7.1f}")
    p = repair_with(heur3, 0.40)
    print(f"{'heuristic-gated (conf<0.60)':34}{p[0]:7.1f}{p[1]:7.1f}{p[2]:7.1f}")
    p = repair_with(lr3, thr_lr)
    print(f"{'learned-gated (LogReg)':34}{p[0]:7.1f}{p[1]:7.1f}{p[2]:7.1f}")
    p = repair_with(gb3, thr_gb)
    print(f"{'learned-gated (GradBoost)':34}{p[0]:7.1f}{p[1]:7.1f}{p[2]:7.1f}")
    print(f"\n(all gates repair ~{100*budget:.0f}% of nodes -> equal budget, fair comparison)")


if __name__ == "__main__":
    folder = sys.argv[1] if len(sys.argv) > 1 else "."
    seeds = int(sys.argv[2]) if len(sys.argv) > 2 else 10
    run(folder, seeds)
