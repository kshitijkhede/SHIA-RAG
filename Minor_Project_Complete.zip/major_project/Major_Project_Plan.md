# Major Project — Plan (builds ON TOP OF the minor's document tree)

**Student:** Kshitij Khede (252IT010) · M.Tech IT, NITK Surathkal
**Guide:** Prof. Ananthanarayana V. S.

> **Relationship to the minor project.** The minor project delivers a *document-tree builder* — it
> turns a PDF into a validated section tree (title → sections → subsections). The major project takes
> that tree as its **input** and builds retrieval, robustness, and learning on top of it. The two are
> kept separate: the minor is "construct the tree"; the major is "use, harden, and learn on the tree."

---

## 1. Aim
To build a full **structure-aware Retrieval-Augmented Generation** system on top of the document tree
from the minor project, to make it **robust** to real parsing noise, and to make its structural
confidence **learned** rather than heuristic — evaluated against flat-chunk RAG on end-task question
answering.

## 2. Objectives
- **O1 — Tree retrieval + QA.** Retrieve along the document tree (attach ancestor context) and answer
  questions with an LLM; compare answer quality against flat-chunk RAG. *(The minor showed the tree
  preserves structure; O1 shows that structure improves answers.)*
- **O2 — Robustness of the tree.** Quantify how the retrieval context degrades when the recovered
  structure is imperfect (reading-order noise ρ, heading-number dropout δ), using model-free metrics
  (PAA, APA = ancestor context, ACP).
- **O3 — Learned structural confidence.** Replace the minor's heuristic KCE with a *trained*
  attachment-error detector, and use it to detect and repair weak structure at inference time.
- **O4 — Generalisation.** Extend to non-academic and heterogeneous documents and to larger public
  benchmarks (e.g. evidence-dense document-QA sets).

## 3. Work already prototyped for the major (kept out of the minor)
The following were built and measured during exploration and belong to the major project:

- **Robustness study (O2).** A perturbation harness + PAA/APA/ACP metrics + a confidence-gated repair.
  Measured on 11 papers × 5 seeds: reading-order noise is nearly harmless (APA 96.8→96.4 at 50%),
  heading-number loss degrades structure (APA 96.8→89.2 at 50%). Code: `major_project/robustness_eval.py`.
- **Learned attachment-error detector (O3).** A gradient-boosted classifier over 15 per-node
  structural features, evaluated leave-one-document-out. Detection improves over the heuristic from
  ROC-AUC 0.65→0.82, PR-AUC 0.10→0.36, r 0.09→0.38; learned-gated repair beats the heuristic gate
  (APA 92.6→93.5 vs 93.2). Code: `major_project/learned_detector.py`.

These give the major project a running start on O2 and O3; O1 (retrieval + LLM QA) and O4
(generalisation) are the new build.

## 4. Method (per objective)
- **O1:** index every tree node with its text + ancestor path; retrieve top-k nodes; attach ancestor
  context; generate an answer with an LLM (GPU available). Baseline = flat fixed-size chunk RAG.
  Metric = answer accuracy / fact coverage on a QA set; also retrieval hit-rate.
- **O2:** inject ρ, δ into the tree; measure PAA/APA/ACP degradation curves; already prototyped.
- **O3:** train the error detector on perturbed trees (features from the node + its predicted edge);
  gate the repair on the learned probability; already prototyped, to be scaled with richer features
  (e.g. heading-neighbourhood embeddings) on the GPU.
- **O4:** run on non-academic PDFs and a public evidence-dense benchmark; report where layout cues
  weaken and the learned signal matters most.

## 5. Datasets
- The 11-paper corpus (shared with the minor) for structural metrics.
- A document-QA benchmark with answers (for O1 end-task evaluation).
- A larger, more heterogeneous PDF set for O4.

## 6. Evaluation
- **Structural:** PAA, APA, ACP (from the minor).
- **Detection:** ROC-AUC, PR-AUC, correlation (leave-one-document-out).
- **End-task (new):** answer accuracy / fact coverage vs flat-chunk RAG; retrieval hit-rate; cost.

## 7. Indicative timeline
- **Phase 1:** O1 — tree retrieval + LLM QA + flat-chunk baseline.
- **Phase 2:** O2 — robustness curves (extend the prototype).
- **Phase 3:** O3 — scale the learned detector; learned-gated repair; ablation.
- **Phase 4:** O4 — generalisation + larger benchmark; write-up.

## 8. Expected contributions
An end-to-end structure-aware RAG system built on a training-free document tree; the first robustness
characterisation of that tree under parser noise; a learned structural-confidence detector with
inference-time repair; and an end-task comparison against flat-chunk RAG.

**Key references:** RAPTOR (ICLR 2024), TreeRAG (ACL Findings 2025), HiChunk (arXiv:2509.11552),
Self-RAG (ICLR 2024), RAG (NeurIPS 2020).
