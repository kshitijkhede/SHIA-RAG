# Minor Project (IT897) — Hierarchical Document-Tree Construction for Structure-Aware RAG

**Author:** Kshitij Khede (252IT010) · M.Tech Information Technology, NITK Surathkal
**Guide:** Prof. Ananthanarayana V. S.

## What this project does
Standard RAG breaks a document into **flat, fixed-size chunks**, which cut across sections and lose
the relationship between a subsection and its section. This project builds a system that converts a
document (PDF) into a **hierarchical tree** — title → sections → subsections — so retrieval can follow
the document's real structure, in the spirit of TreeRAG and RAPTOR.

Pipeline (only ingestion uses a library; the rest are the project's own algorithms):
`PDF → ingestion → reading-order recovery → heading classification → hierarchy induction →
graph validation → KCE confidence → document tree`

## Results (on 11 research papers)
- **11 / 11 valid trees built** (acyclic, single-parent, depth-bounded); mean 22.2 nodes, 21.2
  parent–child links, depth 2.4.
- Tree matches each document's own section numbering: **PAA 97.7% · APA 96.8% · ACP 97.3%**.
- **Tree vs flat chunking (same documents):** flat chunking makes ~69 chunks/doc, **18.8%** of which
  straddle ≥2 sections, and keeps **0** parent–child links; the tree keeps every section intact and
  preserves all **21.2** links/doc.

## Directory layout
```
report/    Minor_Project_Report.pdf   — the full report (24 pp), + main.tex + images/
src/       shia_minor/                — the tree-construction pipeline (this project's code)
           app.py, templates/         — Flask web demo: upload a PDF, see the tree
           tree_eval.py               — tree-construction accuracy + tree-vs-flat-chunk comparison
           run_demo.py                — command-line demo
results/   tree_results.txt           — raw output of tree_eval.py
figures/   tree_vs_chunks_figure.png
docs/      Minor_Viva_Prep.md, Minor_Slides_Content.md

major_project/   — SEPARATE follow-on work (NOT part of the minor); builds ON TOP OF the tree
           Major_Project_Plan.md
           robustness_eval.py, learned_detector.py    — prototypes for the major's O2/O3
           robustness_results.txt, learned_detector_results.txt
           figures/
```

## Reproduce
```bash
python -m venv venv && source venv/bin/activate
pip install pdfplumber scikit-learn numpy pydantic flask matplotlib
cd src
python tree_eval.py <folder-of-pdfs>     # -> tree-construction + flat-chunk comparison
python app.py                            # web demo at http://127.0.0.1:5000
```

## Minor vs Major (kept separate on purpose)
- **Minor (this project):** *construct* the document tree from a PDF, and show it preserves structure
  flat chunking loses.
- **Major (see `major_project/`):** *use* the tree — retrieval + question answering vs flat-chunk RAG,
  robustness to parser noise, and a learned structural-confidence detector.
