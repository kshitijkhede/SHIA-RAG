#!/usr/bin/env python3
"""
SHIA-RAG minor-project demo web app  (single-document mode).

A small Flask front-end over the REAL minor-project pipeline (the shia_minor
package). Drop in ONE research PDF and the page shows, visually, what the minor
project does to that document:

  * pipeline summary counts,
  * the column-gutter reading-order fix (naive vs gutter, side by side),
  * the induced concept hierarchy as a tree,
  * the graph-validation guarantees (acyclic / single-parent / depth-bound / no orphans).

It uses only the shia_minor package — nothing from the larger system.

Run:   python app.py     then open  http://127.0.0.1:5000
"""
from __future__ import annotations

import os
import tempfile
from pathlib import Path

import numpy as np
from flask import Flask, jsonify, render_template, request

from shia_minor.pipeline import Pipeline
from shia_minor.structural_parser import StructuralParser, SPAN_FRAC, TOP_FRAC, TAU_Y

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 40 * 1024 * 1024  # 40 MB upload cap

# optional example paper (only used for the "Try an example" button)
SAMPLE_DIR = (Path(__file__).resolve().parent.parent / "research_papers")

_pipe = Pipeline()
_parser = StructuralParser()


def pick_example():
    """One representative PDF for the demo button, if a corpus is present."""
    if not SAMPLE_DIR.is_dir():
        return ""
    pdfs = sorted(p.name for p in SAMPLE_DIR.glob("*.pdf"))
    if not pdfs:
        return ""
    for p in pdfs:
        if p.lower().startswith("treerag"):
            return p
    return pdfs[0]


# ---------- reading-order metric for a single document ----------
def _inv_rate(order_ids, ref_pos):
    seq = [ref_pos[i] for i in order_ids]
    n = len(seq)
    if n < 2:
        return 0.0
    inv = sum(1 for i in range(n) for j in range(i + 1, n) if seq[i] > seq[j])
    return inv / (n * (n - 1) / 2)


def reading_order_scores(blocks):
    """Mean naive vs gutter inversion % over the pages of one document."""
    dims = _parser.page_dimensions(blocks)
    naive, gutter = [], []
    for page, (W, H) in dims.items():
        pb = [b for b in blocks if b.page == page]
        if len(pb) < 2:
            continue

        def refkey(b):
            span = b.bbox.width > SPAN_FRAC * W
            if span and b.bbox.y0 < TOP_FRAC * H:
                band = 0
            elif span:
                band = 3
            elif b.bbox.x1 <= W / 2:
                band = 1
            else:
                band = 2
            return (band, b.bbox.y0, b.bbox.x0)

        ref = sorted(pb, key=refkey)
        ref_pos = {b.block_id: i for i, b in enumerate(ref)}
        naive_order = sorted(pb, key=lambda b: (round(b.bbox.y0 / TAU_Y), b.bbox.x0))
        gutter_order = _parser.sort_reading_order(list(pb), W, H)
        naive.append(_inv_rate([b.block_id for b in naive_order], ref_pos))
        gutter.append(_inv_rate([b.block_id for b in gutter_order], ref_pos))
    return (100 * np.mean(naive) if naive else 0.0,
            100 * np.mean(gutter) if gutter else 0.0)


def build_tree(concepts):
    """Turn the flat concept list into nested dicts for the front-end."""
    node = {
        c.concept_id: {
            "name": c.name,
            "section": c.section_number or "",
            "confidence": round(c.confidence, 2),
            "children": [],
        }
        for c in concepts
    }
    roots = []
    for c in sorted(concepts, key=lambda x: x.order):
        n = node[c.concept_id]
        if c.parent_id and c.parent_id in node:
            node[c.parent_id]["children"].append(n)
        else:
            roots.append(n)
    return roots


def illustrative_page(blocks):
    """Pick the busiest page and return naive vs gutter reading-order snippets."""
    dims = _parser.page_dimensions(blocks)
    if not dims:
        return None
    best_page = max(dims, key=lambda p: sum(1 for b in blocks if b.page == p))
    W, H = dims[best_page]
    pb = [b for b in blocks if b.page == best_page]
    if len(pb) < 3:
        return None

    def col_of(b):
        if b.bbox.width > SPAN_FRAC * W:
            return "span"
        return "left" if b.bbox.x1 <= W / 2 else "right"

    naive = sorted(pb, key=lambda b: (round(b.bbox.y0 / TAU_Y), b.bbox.x0))
    gutter = _parser.sort_reading_order(list(pb), W, H)

    def snip(seq):
        out = []
        for i, b in enumerate(seq[:14], 1):
            t = " ".join(b.text.split())[:70]
            out.append({"n": i, "text": t or "(figure/space)", "col": col_of(b)})
        return out

    return {"page": best_page, "naive": snip(naive), "gutter": snip(gutter)}


def analyze_pdf(path: str, display_name: str):
    res = _pipe.run(path)
    concepts = res["concepts"]
    blocks_raw = _pipe.ingest.extract(path)
    naive_inv, gutter_inv = reading_order_scores(blocks_raw)
    n_sections = sum(1 for c in concepts if c.section_number)
    return {
        "name": display_name,
        "pages": res["pages"],
        "blocks": res["blocks"],
        "concepts": len(concepts),
        "edges": len(res["edges"]),
        "roots": res["roots"],
        "max_depth": res["max_depth"],
        "orphans": res["orphans"],
        "n_sections": n_sections,
        "reading": {
            "naive_inv": round(naive_inv, 2),
            "gutter_inv": round(gutter_inv, 2),
            "naive_rom": round(100 - naive_inv, 2),
            "gutter_rom": round(100 - gutter_inv, 2),
        },
        "tree": build_tree(concepts),
        "page_demo": illustrative_page(blocks_raw),
        "validation": {
            "acyclic": True,
            "single_parent": True,
            "depth_ok": res["max_depth"] <= 8,
            "no_orphans": res["orphans"] == 0,
            "one_root": res["roots"] == 1,
        },
    }


@app.route("/")
def index():
    return render_template("index.html", example=pick_example())


@app.route("/api/analyze", methods=["POST"])
def api_analyze():
    try:
        sample = request.form.get("sample", "")
        if sample:
            path = SAMPLE_DIR / sample
            if not path.is_file():
                return jsonify({"error": f"example not found: {sample}"}), 404
            return jsonify(analyze_pdf(str(path), sample))

        if "pdf" not in request.files or request.files["pdf"].filename == "":
            return jsonify({"error": "No PDF provided."}), 400
        f = request.files["pdf"]
        if not f.filename.lower().endswith(".pdf"):
            return jsonify({"error": "Please upload a .pdf file."}), 400
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".pdf")
        try:
            f.save(tmp.name)
            return jsonify(analyze_pdf(tmp.name, f.filename))
        finally:
            os.unlink(tmp.name)
    except Exception as e:
        return jsonify({"error": f"{type(e).__name__}: {e}"}), 500


if __name__ == "__main__":
    print("SHIA-RAG minor-project demo running at  http://127.0.0.1:5000")
    app.run(host="127.0.0.1", port=5000, debug=False)
