#!/usr/bin/env python3
"""
Minor-project evaluation: DOCUMENT-TREE CONSTRUCTION (not flat chunks).

Measures (a) the tree the system builds from each PDF and how well it matches the
document's true section hierarchy, and (b) a direct comparison against fixed-size
(flat) chunking, showing that flat chunks cut across sections and encode no
parent-child structure, while the tree preserves both.

Usage: python tree_eval.py <folder-of-pdfs>
"""
from __future__ import annotations
import sys, statistics
from pathlib import Path

from shia_minor.pdf_ingestion import PDFIngestionService
from shia_minor.structural_parser import StructuralParser
from shia_minor.concept_extractor import ConceptExtractor
from shia_minor.hierarchy_builder import HierarchyBuilder
from shia_minor.kce_scorer import KCEScorer
from shia_minor.pipeline import Pipeline

from shia_minor.tree_metrics import gold_maps, score


def tree_stats(concepts):
    n = len(concepts)
    nodes = {c.concept_id: c for c in concepts}
    roots = [c for c in concepts if c.parent_id is None]
    edges = sum(1 for c in concepts if c.parent_id is not None)
    depths = [c.depth for c in concepts]
    numbered = sum(1 for c in concepts if c.section_number)
    # validity: single-parent (by construction), acyclic, depth-bounded
    acyclic = True
    for c in concepts:
        seen, cur = set(), c
        while cur.parent_id is not None:
            if cur.concept_id in seen:
                acyclic = False; break
            seen.add(cur.concept_id); cur = nodes.get(cur.parent_id)
            if cur is None:
                break
    depth_ok = max(depths) <= 8 if depths else True
    internal = sum(1 for c in concepts if any(x.parent_id == c.concept_id for x in concepts))
    branching = edges / internal if internal else 0.0
    return {
        "nodes": n, "edges": edges, "max_depth": max(depths) if depths else 0,
        "numbered": numbered, "unnumbered": n - numbered, "roots": len(roots),
        "branching": branching, "valid": acyclic and depth_ok and len(roots) >= 1,
    }


def section_membership(ordered, parser, body):
    """Assign each block a section id; a new section starts at every heading block."""
    sec, ids = -1, []
    for b in ordered:
        is_head, _, _ = parser.classify_heading(b, body)
        if is_head:
            sec += 1
        ids.append(max(sec, 0))
    return ids


def flatchunk_compare(ordered, parser, body, tree_edges, win=1200):
    """Fixed-size (flat) chunking vs the section tree, on the same document text."""
    ids = section_membership(ordered, parser, body)
    # linear char stream, remembering each character's section id
    stream_sec = []
    for b, sid in zip(ordered, ids):
        t = (b.text or "").strip()
        if not t:
            continue
        stream_sec.extend([sid] * (len(t) + 1))     # +1 for the joining space
    total = len(stream_sec)
    n_sections = (max(ids) + 1) if ids else 0
    if total == 0:
        return None
    # fixed-size windows
    chunks = [stream_sec[i:i + win] for i in range(0, total, win)]
    cross = sum(1 for ch in chunks if len(set(ch)) > 1)   # straddles >=2 sections
    return {
        "fx_chunks": len(chunks),
        "fx_cross": cross,
        "fx_cross_pct": 100.0 * cross / len(chunks) if chunks else 0.0,
        "tree_sections": n_sections,
        "tree_edges": tree_edges,        # parent-child relationships the tree keeps
    }


def run(folder):
    pdfs = sorted(Path(folder).glob("*.pdf"))
    ingest = PDFIngestionService(); pipe = Pipeline(); parser = StructuralParser()
    extr = ConceptExtractor(); builder = HierarchyBuilder(); kce = KCEScorer()

    rows, fid, fx = [], [], []
    print(f"{'document':26}{'nodes':>6}{'edges':>6}{'depth':>6}{'num':>5}{'unnum':>6}"
          f"{'valid':>6}{'PAA':>7}{'APA':>7}")
    for pdf in pdfs:
        blocks = ingest.extract(str(pdf))
        ordered = pipe.sort_blocks(blocks)
        body = parser.body_font_size(ordered)
        concepts = extr.extract(ordered, pdf.stem[:16])
        builder.build(concepts); kce.score(concepts)
        st = tree_stats(concepts)
        gp, ga = gold_maps(concepts)
        sc = score(concepts, gp, ga) if gp else None
        paa = sc[0] if sc else float("nan"); apa = sc[1] if sc else float("nan")
        cmp = flatchunk_compare(ordered, parser, body, st["edges"])
        rows.append(st)
        if sc: fid.append((paa, apa, sc[2]))
        if cmp: fx.append(cmp)
        print(f"{pdf.stem[:24]:26}{st['nodes']:6d}{st['edges']:6d}{st['max_depth']:6d}"
              f"{st['numbered']:5d}{st['unnumbered']:6d}{str(st['valid']):>6}"
              f"{paa:7.1f}{apa:7.1f}")

    print("\n=== Tree construction (corpus averages) ===")
    print(f"documents                : {len(rows)}")
    print(f"mean nodes / document    : {statistics.mean(r['nodes'] for r in rows):.1f}")
    print(f"mean parent-child edges  : {statistics.mean(r['edges'] for r in rows):.1f}")
    print(f"mean tree depth          : {statistics.mean(r['max_depth'] for r in rows):.1f}")
    print(f"mean branching factor    : {statistics.mean(r['branching'] for r in rows):.2f}")
    print(f"valid trees              : {sum(r['valid'] for r in rows)}/{len(rows)} "
          f"(acyclic, single-parent, depth<=8)")

    print("\n=== Tree fidelity vs. document's own section numbering (clean build) ===")
    print(f"Parent-Assignment Accuracy (PAA) : {statistics.mean(f[0] for f in fid):.1f}%")
    print(f"Ancestor-Path Accuracy    (APA)  : {statistics.mean(f[1] for f in fid):.1f}%")
    print(f"Ancestor-Context Precision (ACP) : {statistics.mean(f[2] for f in fid):.1f}%")

    print("\n=== Tree vs. flat fixed-size chunking (same documents, 1200-char chunks) ===")
    mc = statistics.mean(f["fx_cross_pct"] for f in fx)
    print(f"flat chunks / document               : {statistics.mean(f['fx_chunks'] for f in fx):.1f}")
    print(f"flat chunks that straddle >=2 sections: {mc:.1f}%   <-- structure lost")
    print(f"parent-child links in flat chunks     : 0            (flat chunking has no hierarchy)")
    print(f"tree section-nodes / document         : {statistics.mean(f['tree_sections'] for f in fx):.1f}")
    print(f"tree chunks that straddle sections    : 0.0%         (each node = one section)")
    print(f"parent-child links preserved by tree  : {statistics.mean(f['tree_edges'] for f in fx):.1f} / document")


if __name__ == "__main__":
    run(sys.argv[1] if len(sys.argv) > 1 else ".")
