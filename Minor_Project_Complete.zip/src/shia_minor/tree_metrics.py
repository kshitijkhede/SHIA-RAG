"""
Tree-fidelity metrics: compare the induced hierarchy against the document's own
section numbering (an objective gold parent map).

  PAA  - Parent-Assignment Accuracy (correct immediate parent)
  APA  - Ancestor-Path Accuracy (the full root->node lineage is correct)
  ACP  - Ancestor-Context Precision (fraction of attached ancestors that are correct)
"""
from __future__ import annotations
import statistics


def gold_maps(concepts):
    """Gold parent map + ancestor chain from each node's original section number."""
    by_num = {c.section_number: c.concept_id for c in concepts if c.section_number}
    gp = {}
    for c in concepts:
        if not c.section_number:
            continue
        if "." in c.section_number:
            pn = c.section_number.rsplit(".", 1)[0]
            gp[c.concept_id] = by_num.get(pn, "ROOT")
        else:
            gp[c.concept_id] = "ROOT"
    ga = {}
    for cid in gp:
        chain, cur, seen = [], cid, set()
        while cur in gp and gp[cur] != "ROOT" and cur not in seen:
            seen.add(cur); cur = gp[cur]; chain.append(cur)
        ga[cid] = chain
    return gp, ga


def pred_maps(concepts):
    """Predicted parent map; the single document-title root is treated as ROOT."""
    roots = {c.concept_id for c in concepts if c.parent_id is None}
    pp = {}
    for c in concepts:
        p = c.parent_id
        pp[c.concept_id] = "ROOT" if (p is None or p in roots) else p
    pa = {}
    for cid in pp:
        chain, cur, seen = [], cid, set()
        while pp.get(cur, "ROOT") != "ROOT" and cur not in seen:
            seen.add(cur); cur = pp[cur]; chain.append(cur)
        pa[cid] = chain
    return pp, pa


def score(concepts, gp, ga):
    """Return (PAA, APA, ACP, predicted-parent-map, keys) over numbered nodes."""
    pp, pa = pred_maps(concepts)
    keys = list(gp)
    if not keys:
        return None
    paa = 100.0 * sum(1 for k in keys if pp.get(k, "ROOT") == gp[k]) / len(keys)
    apa = 100.0 * sum(1 for k in keys if set(pa.get(k, [])) == set(ga[k])) / len(keys)
    acp_vals = []
    for k in keys:
        pset = set(pa.get(k, []))
        if not pset:
            acp_vals.append(1.0 if not ga[k] else 0.0)
        else:
            acp_vals.append(len(pset & set(ga[k])) / len(pset))
    acp = 100.0 * statistics.mean(acp_vals)
    return paa, apa, acp, pp, keys
