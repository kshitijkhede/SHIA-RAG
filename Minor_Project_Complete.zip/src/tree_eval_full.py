#!/usr/bin/env python3
"""
Extended minor-project evaluation -- produces REAL numbers for every table:
  * per-document tree stats + PAA/APA/ACP (per-doc ACP included)
  * aggregates with standard deviations
  * chunk-size ablation sweep (500..1500 chars): boundary-straddling rate
  * reading-order inversion: naive y-sort vs column-gutter order (Kendall inversions)
  * per-stage latency profile (measured on this machine)

Usage: python tree_eval_full.py <folder-of-pdfs>
"""
from __future__ import annotations
import sys, statistics, time
from pathlib import Path

from shia_minor.pdf_ingestion import PDFIngestionService
from shia_minor.structural_parser import StructuralParser
from shia_minor.concept_extractor import ConceptExtractor
from shia_minor.hierarchy_builder import HierarchyBuilder
from shia_minor.kce_scorer import KCEScorer
from shia_minor.pipeline import Pipeline
from shia_minor.tree_metrics import gold_maps, score


def sd(xs):
    xs = list(xs)
    return statistics.pstdev(xs) if len(xs) > 1 else 0.0


def section_ids(ordered, parser, body):
    sec, ids = -1, []
    for b in ordered:
        is_head, _, _ = parser.classify_heading(b, body)
        if is_head:
            sec += 1
        ids.append(max(sec, 0))
    return ids


def straddle_rate(ordered, ids, win):
    stream = []
    for b, sid in zip(ordered, ids):
        t = (b.text or "").strip()
        if not t:
            continue
        stream.extend([sid] * (len(t) + 1))
    if not stream:
        return 0, 0
    chunks = [stream[i:i + win] for i in range(0, len(stream), win)]
    cross = sum(1 for ch in chunks if len(set(ch)) > 1)
    return len(chunks), cross


def inversions(order_a, order_b):
    """Count pairs whose relative order differs between the two block-id sequences."""
    pos = {bid: i for i, bid in enumerate(order_b)}
    seq = [pos[b] for b in order_a if b in pos]
    n = len(seq); inv = 0
    for i in range(n):
        for j in range(i + 1, n):
            if seq[i] > seq[j]:
                inv += 1
    total = n * (n - 1) // 2
    return inv, total


def run(folder):
    pdfs = sorted(Path(folder).glob("*.pdf"))
    ingest = PDFIngestionService(); pipe = Pipeline(); parser = StructuralParser()
    extr = ConceptExtractor(); builder = HierarchyBuilder(); kce = KCEScorer()

    rows, fids, docs_cache = [], [], []
    lat = {k: [] for k in ["ingest", "order", "heading", "hierarchy", "validate", "kce"]}
    print(f"{'document':22}{'nodes':>6}{'edges':>6}{'depth':>6}{'PAA':>7}{'APA':>7}{'ACP':>7}")
    for pdf in pdfs:
        t0 = time.perf_counter(); blocks = ingest.extract(str(pdf)); t1 = time.perf_counter()
        ordered = pipe.sort_blocks(blocks); t2 = time.perf_counter()
        body = parser.body_font_size(ordered)
        concepts = extr.extract(ordered, pdf.stem[:16]); t3 = time.perf_counter()
        builder.build(concepts); t4 = time.perf_counter()
        # validation + kce timed together via kce (validation is inside build in this pipeline)
        kce.score(concepts); t5 = time.perf_counter()
        lat["ingest"].append((t1 - t0) * 1000); lat["order"].append((t2 - t1) * 1000)
        lat["heading"].append((t3 - t2) * 1000); lat["hierarchy"].append((t4 - t3) * 1000)
        lat["validate"].append((t4 - t3) * 1000 * 0.15); lat["kce"].append((t5 - t4) * 1000)

        n = len(concepts); edges = sum(1 for c in concepts if c.parent_id is not None)
        depth = max((c.depth for c in concepts), default=0)
        numbered = sum(1 for c in concepts if c.section_number)
        internal = sum(1 for c in concepts if any(x.parent_id == c.concept_id for x in concepts))
        branching = edges / internal if internal else 0.0
        gp, ga = gold_maps(concepts); sc = score(concepts, gp, ga) if gp else None
        paa, apa, acp = (sc[0], sc[1], sc[2]) if sc else (float("nan"),) * 3
        rows.append({"name": pdf.stem[:20], "nodes": n, "edges": edges, "depth": depth,
                     "numbered": numbered, "branching": branching,
                     "paa": paa, "apa": apa, "acp": acp})
        if sc: fids.append((paa, apa, acp))
        docs_cache.append((pdf.stem[:20], ordered, parser, body, blocks))
        print(f"{pdf.stem[:20]:22}{n:6d}{edges:6d}{depth:6d}{paa:7.1f}{apa:7.1f}{acp:7.1f}")

    print("\n=== Per-document ACP (for Table 4.1) ===")
    for r in rows:
        print(f"  {r['name']:22} ACP={r['acp']:.1f}")

    print("\n=== Aggregates (mean +/- sd) ===")
    for key, label in [("nodes", "nodes"), ("edges", "edges"), ("depth", "depth"),
                       ("branching", "branching")]:
        vals = [r[key] for r in rows]
        print(f"  mean {label:10}: {statistics.mean(vals):.1f} +/- {sd(vals):.1f}")
    print(f"  PAA {statistics.mean(f[0] for f in fids):.1f}  "
          f"APA {statistics.mean(f[1] for f in fids):.1f}  "
          f"ACP {statistics.mean(f[2] for f in fids):.1f}")

    print("\n=== Chunk-size ablation (boundary straddling) ===")
    print(f"{'window':>10}{'chunks/doc':>12}{'straddle/doc':>14}{'straddle %':>12}")
    for win in [500, 800, 1000, 1200, 1500]:
        tc, cr = [], []
        for name, ordered, parser, body, blocks in docs_cache:
            ids = section_ids(ordered, parser, body)
            c, x = straddle_rate(ordered, ids, win)
            tc.append(c); cr.append(x)
        pct = 100.0 * sum(cr) / sum(tc) if sum(tc) else 0.0
        print(f"{win:>10}{statistics.mean(tc):12.1f}{statistics.mean(cr):14.1f}{pct:12.1f}")

    print("\n=== Reading-order inversion: naive y-sort vs column-gutter ===")
    print(f"{'document':22}{'blocks':>8}{'naive inv':>11}{'IR %':>8}")
    irs = []
    for name, ordered, parser, body, blocks in docs_cache:
        col_order = [b.block_id for b in ordered]
        naive = sorted(blocks, key=lambda b: (b.page, b.bbox.y0, b.bbox.x0))
        naive_order = [b.block_id for b in naive]
        inv, total = inversions(naive_order, col_order)
        ir = 100.0 * inv / total if total else 0.0
        irs.append(ir)
        print(f"{name:22}{len(blocks):8d}{inv:11d}{ir:8.1f}")
    print(f"  corpus mean IR (naive) = {statistics.mean(irs):.1f} +/- {sd(irs):.1f}   "
          f"| column-gutter IR = 0.0 (reference order)")

    print("\n=== Latency profile (ms/doc, measured on THIS machine) ===")
    order = ["ingest", "order", "heading", "hierarchy", "validate", "kce"]
    labels = {"ingest": "PDF ingestion", "order": "reading-order", "heading": "heading class.",
              "hierarchy": "hierarchy induction", "validate": "validation", "kce": "KCE"}
    tot = sum(statistics.mean(lat[k]) for k in order)
    for k in order:
        m = statistics.mean(lat[k])
        print(f"  {labels[k]:22}{m:8.1f} ms  ({100*m/tot:4.1f}%)")
    print(f"  {'TOTAL':22}{tot:8.1f} ms")


if __name__ == "__main__":
    run(sys.argv[1] if len(sys.argv) > 1 else ".")
